# Made by moi15moi

import math
import random
from pyonfx import *

io = Ass("Input - Effect 1.ass", "Output.ass")
meta, styles, lines = io.get_data()


def romanji(line: Line, l: Line):
    # Lead in
    l.layer = 0
    l.effect = "Leadin"
    l.style = "Ending - Japonais"

    sylDuration = 600
    durationBetweenEachSyl = 60

    i = 1
    for syl in Utils.all_non_empty(line.syls):

        l.start_time = line.start_time - ((durationBetweenEachSyl * i)) - sylDuration
        l.end_time = line.start_time + syl.start_time 
        l.dur = l.end_time - l.start_time
                
        l.text = (
            "{\\an5\\move(%d,0,%d,%d,0,%d)"
            "\\frz90\\t(0,%d,\\frz0)\\blur1"
            "\\org(%d, %d)}%s" % (
                syl.center + 575,
                syl.center,
                syl.middle,
                sylDuration,
                sylDuration,
                syl.center,
                syl.middle,
                syl.text,
            )
        )

        io.write_line(l)
        
        i = i-1

    # Main effect
    for syl in Utils.all_non_empty(line.syls):
        l.layer = 5
        l.effect = "Main effect"
        l.style = "Ending - Japonais"

        l.start_time = line.start_time + syl.start_time
        l.end_time = line.start_time + syl.end_time
        l.dur = l.end_time - l.start_time

        l.text = ("{\\an5\\pos(%d,%d)\\1c&HFFFFFF&\\3c&HFFFFFF&\\blur3"
                    "\\t(0,%d,\\fscx145\\fscy145)"
                    "\\t(%d,%d,\\c&H733223&\\3c&HFFFFFF&\\fscx100\\fscy100\\blur1)"
                    "\\t(0,%d,\\fsp2)\\t(%d,%d,\\fsp0.5)}%s" % (
                    syl.center,
                    syl.middle,
                    l.dur/4,
                    l.dur/4,
                    l.dur,
                    l.dur/2,
                    l.dur/2,
                    l.dur,
                    syl.text
            )
        )
        io.write_line(l)
        
        l.layer = 6
        l.effect = "Main effect Draw"
        l.style = "Pixel"
        l.text = ("{\\an5\\pos(%d,%d)\\blur14\\t(0,%d,\\fscx165\\fscy165)\\t(%d,%d,\\fscx70\\fscy70)\\p1}%s" % (
                    syl.center,
                    syl.middle,
                    l.dur/4,
                    l.dur/4,
                    l.dur,
                    Shape.ellipse(40,40)
            )
        )
        io.write_line(l)

        l.start_time = line.start_time + syl.start_time
        l.end_time = l.start_time + 600
        l.dur = l.end_time - l.start_time
        
        l.layer = 1
        l.effect = ""
        l.style = "Pixel"
        
        length = 70

        for j in range(0,12):
            angle = random.randint(-180, 180)   
            length = random.randint(50, 80) 

            xLength = math.cos(math.radians(angle)) * length
            yLength = math.sin(math.radians(angle)) * length
            
            frz = 110
            if angle >= 0 and angle < 90 :
                frz *= -1
            elif angle >= 90 and angle < 180 :
                frz = frz
            elif angle >= -180 and angle < -90 :
                frz = frz
            elif angle >= -90 and angle < 0 :
                frz *= -1

            l.text = ("{\\move(%d,%d,%d,%d)\\blur2\\t(\\frz%d\\blur0.5\\1a&HFF&\\fscx70\\fscy70)\\p1}%s" % (
                    syl.center,
                    syl.middle,                    
                    syl.center + xLength,
                    syl.middle + yLength,
                    frz,
                    "m 18 36 b 20 23 20 13 18 0 b 16 13 16 23 18 36 m 0 18 b 13 20 23 20 36 18 b 23 16 13 16 0 18"
                )
            )
            io.write_line(l)

    # Lead out
    l.layer = 0
    l.effect = "Lead out"
    l.style = "Ending - Japonais"
    
    i = 0
    leadout = 600
    for char in Utils.all_non_empty(line.chars):

        l.start_time = line.start_time + char.end_time
        l.end_time = line.end_time + leadout
        l.dur = l.end_time - l.start_time

        frz = 90
        if i % 2 == 0:
            frz *= -1
        
        minValue = 60
        maxValue = 120

        iFromMiddle = abs(i - (len(Utils.all_non_empty(line.chars))-1)//2)

        middle = maxValue - iFromMiddle * (maxValue - minValue)/((len(Utils.all_non_empty(line.chars))-1)//2)
    
        l.text = ("{\\an5\\move(%d,%d,%d,%d,%d,%d)\\c&H733223&\\3c&HFFFFFF&\\t(%d,%d,\\frz%d)\\blur1\\fad(0,%d)}%s" % (
                    char.center,
                    char.middle,                    
                    char.center,
                    char.middle + middle,
                    line.end_time - l.start_time,
                    l.dur,

                    line.end_time - l.start_time,
                    l.dur,
                    frz,

                    leadout,
                    char.text
            )
        )
        io.write_line(l)

        i += 1



def translation(line, l):
    leadin = 200
    leadout = 300

    l.start_time = line.start_time - leadin
    l.end_time = line.end_time + leadout
    l.dur = l.end_time - l.start_time

    l.text = (
        "{\\an5\\pos(%.3f,%.3f)\\fad(%d, %d)}%s" % (
            line.center,
            line.middle,
            leadin,
            leadout,
            line.raw_text,
        )
    )

    io.write_line(l)


for line in lines:



    # Generating lines
    if line.style == "Ending - Japonais":
        romanji(line, line.copy())
    elif line.style == "Ending - Traduction":
        translation(line, line.copy())


io.save()
io.open_aegisub()